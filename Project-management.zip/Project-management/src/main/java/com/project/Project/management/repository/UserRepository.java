package com.project.Project.management.repository;

import com.project.Project.management.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.project.Project.management.utils.Status;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsernameAndStatus(String username, Status status);
}
