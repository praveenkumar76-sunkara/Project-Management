package com.project.Project.management.repository;


import com.project.Project.management.domain.Project;
import com.project.Project.management.utils.Status;
import lombok.NonNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> {


    Optional<Project> findByNameAndStatus(@NonNull String name, Status status);

    Optional<Project> findByIdAndStatus(Long projectId, Status status);
}
