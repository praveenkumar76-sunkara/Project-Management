package com.project.Project.management.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.project.Project.management.utils.Priority;
import com.project.Project.management.utils.Status;
import com.project.Project.management.utils.TaskStatus;

import java.util.Date;

@Entity
@Table(name = "tasks")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "task_name")
    private String taskName;

    @Column(name = "description")
    private String description;

    @Column
    private Priority priority;

    @Column
    private TaskStatus taskStatus;

    @Column
    private Status status;

    @Column
    private Date dueDate;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "updated_at")
    private Date updatedAt;

    @ManyToOne
    @JoinColumn(name = "project_id")
    private Project project;
}
