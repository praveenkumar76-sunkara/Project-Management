package com.project.Project.management.service;

import com.project.Project.management.domain.User;

public interface UserService {
    void registerUser(User user);

    String loginUser(User user);
}
