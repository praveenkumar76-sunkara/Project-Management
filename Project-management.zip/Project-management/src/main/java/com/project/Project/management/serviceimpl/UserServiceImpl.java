package com.project.Project.management.serviceimpl;

import com.project.Project.management.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.project.Project.management.repository.UserRepository;
import com.project.Project.management.service.UserService;
import com.project.Project.management.utils.JwtUtility;
import com.project.Project.management.utils.Status;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtility jwtUtility;

    @Override
    public void registerUser(User user) {

        User existingUsers = userRepository.findByUsernameAndStatus(user.getUsername(), Status.ACTIVE);
        if (existingUsers != null) {
            throw new RuntimeException("User Already Exists for the given Username");
        }
        User users = new User();
        users.setUsername(user.getUsername());
        users.setPassword(passwordEncoder.encode(user.getPassword()));
        users.setProjects(user.getProjects());
        users.setStatus(Status.ACTIVE);
        userRepository.save(users);

    }

    @Override
    public String loginUser(User user) {
        User existingUsers = userRepository.findByUsernameAndStatus(user.getUsername(), Status.ACTIVE);
        if (existingUsers == null) {
            throw new RuntimeException("User Not Exists for the given Username");
        }
        if (!passwordEncoder.matches(user.getPassword(), existingUsers.getPassword())) {
            throw new RuntimeException("Wrong Password");
        }
        return jwtUtility.generateToken(existingUsers.getUsername());

    }
}
