package com.project.Project.management.dto;

import com.project.Project.management.domain.Project;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsersDTO {

    private Long id;

    private String username;

    private String password;

    @OneToMany
    private List<Project> projects;
}
