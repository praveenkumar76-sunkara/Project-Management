package com.project.Project.management.controller;

import com.project.Project.management.dto.TaskDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.project.Project.management.service.TaskService;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/task")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @PostMapping("/create")
    public ResponseEntity<String> addProject(@RequestBody TaskDTO taskDTO) {
        try {
            taskService.createTask(taskDTO);
            return ResponseEntity.ok("Task Created Successfully");
        }catch (Exception e){
            log.error("Exception occurred while creating task", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/list/{taskId}")
    public ResponseEntity<TaskDTO> getProject(@PathVariable Long taskId) {
        try {
            TaskDTO taskDTO = taskService.getTask(taskId);
            if(taskDTO == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
            return ResponseEntity.ok(taskDTO);
        }catch (Exception e){
            log.error("Exception occurred while creating task", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/list")
    public ResponseEntity<List<TaskDTO>> getAllProject( @RequestParam List<Long> projectIds,
                                                        @RequestParam(required = false) String search,
                                                        @RequestParam(defaultValue = "dueDate") String sortBy,
                                                        @RequestParam(defaultValue = "0") String page,
                                                        @RequestParam(defaultValue = "20") String size) {
        List<TaskDTO> taskDTOS = taskService.getTasks(projectIds,search,sortBy,page,size);
        return ResponseEntity.ok(taskDTOS);
    }

    @PutMapping("/update")
    public ResponseEntity<String> updateProject(@RequestBody TaskDTO taskDTO) {
        try {
            taskService.createTask(taskDTO);
            return ResponseEntity.ok("Task Updated Successfully");
        }catch (Exception e){
            log.error("Exception occurred while updating task", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

    }

    @DeleteMapping("/delete/{taskId}")
    public ResponseEntity<String> deleteProject(@PathVariable Long taskId) {
        taskService.deleteTask(taskId);
        return ResponseEntity.ok("Task Deleted Successfully");
    }
}
