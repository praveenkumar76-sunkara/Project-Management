package com.project.Project.management.service;

import com.project.Project.management.dto.ProjectDTO;

public interface ProjectService {
    void createProject(ProjectDTO projectDTO);

    ProjectDTO getProject(Long projectId);

    void deleteProject(Long projectId);
}
