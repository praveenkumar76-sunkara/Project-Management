package com.project.Project.management.controller;

import com.project.Project.management.dto.ProjectDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.project.Project.management.service.ProjectService;

@Slf4j
@RestController
@RequestMapping("/api/project")
public class ProjectsController {

    @Autowired
    private ProjectService projectService;


    @PostMapping("/create")
    public ResponseEntity<String> addProject(@RequestBody ProjectDTO projectDTO) {
        try {
            projectService.createProject(projectDTO);
            return ResponseEntity.ok("Project Created Successfully");
        }catch (Exception e){
            log.error("Exception occurred while creating project", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/view/{projectId}")
    public ResponseEntity<ProjectDTO> getProject(@PathVariable Long projectId) {
        try {
            ProjectDTO projectDTO1 = projectService.getProject(projectId);
            if(projectDTO1 == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
            return ResponseEntity.ok(projectDTO1);
        }catch (Exception e){
            log.error("Exception occurred while creating project", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping("/update")
    public ResponseEntity<String> updateProject(@RequestBody  ProjectDTO projectDTO) {
        try {
            projectService.createProject(projectDTO);
            return ResponseEntity.ok("Project Updated Successfully");
        }catch (Exception e){
            log.error("Exception occurred while updating project", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

    }

    @DeleteMapping("/delete/{projectId}")
    public ResponseEntity<String> deleteProject(@PathVariable Long projectId) {
        projectService.deleteProject(projectId);
        return ResponseEntity.ok("Project Deleted Successfully");
    }
}
