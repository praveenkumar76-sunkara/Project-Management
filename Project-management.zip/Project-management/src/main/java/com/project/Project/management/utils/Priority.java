package com.project.Project.management.utils;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}
