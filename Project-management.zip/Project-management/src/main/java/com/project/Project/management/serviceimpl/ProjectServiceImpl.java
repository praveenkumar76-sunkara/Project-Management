package com.project.Project.management.serviceimpl;


import com.project.Project.management.domain.Project;
import com.project.Project.management.dto.ProjectDTO;
import com.project.Project.management.mapper.ProjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.project.Project.management.repository.ProjectRepository;
import com.project.Project.management.service.ProjectService;
import com.project.Project.management.utils.Status;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class ProjectServiceImpl implements ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private ProjectMapper projectMapper;

    /* I am using below method as common for both create project API and update project API*/

    @Override
    public void createProject(ProjectDTO projectDTO) {
        Project project;
        Optional<Project> existingProject = projectRepository.findByNameAndStatus(projectDTO.getName(), Status.ACTIVE);
        if (existingProject.isPresent()) {
            project = existingProject.get();
        } else {
            project = new Project();
            project.setCreatedAt(Timestamp.valueOf(LocalDateTime.now()));
        }
        project.setName(projectDTO.getName());
        project.setDescription(projectDTO.getDescription());
        project.setUpdatedAt(Timestamp.valueOf(LocalDateTime.now()));
        project.setStatus(Status.ACTIVE);
        projectRepository.save(project);
    }

    @Override
    public ProjectDTO getProject(Long projectId) {
        Optional<Project> project = projectRepository.findByIdAndStatus(projectId, Status.ACTIVE);
        if (project.isEmpty()) {
            return null;
        }
        return projectMapper.toDto(project.get());
    }

    @Override
    public void deleteProject(Long projectId) {
        Optional<Project> project = projectRepository.findByIdAndStatus(projectId, Status.ACTIVE);
        if (project.isEmpty()) {
            return;
        }
        Project proj = project.get();
        proj.setStatus(Status.DELETED);
        projectRepository.save(proj);
    }
}
