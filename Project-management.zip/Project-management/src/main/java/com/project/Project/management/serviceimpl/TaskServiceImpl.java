package com.project.Project.management.serviceimpl;

import com.project.Project.management.domain.Project;
import com.project.Project.management.domain.Task;
import com.project.Project.management.dto.TaskDTO;
import com.project.Project.management.mapper.TaskMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.project.Project.management.repository.TaskRepository;
import com.project.Project.management.service.TaskService;
import com.project.Project.management.utils.Status;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class TaskServiceImpl implements TaskService {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private TaskMapper taskMapper;

    @Override
    public void createTask(TaskDTO taskDTO) {

        Task task = taskRepository.findByTaskNameAndStatus(taskDTO.getTaskName(), Status.ACTIVE).orElse(null);
        Project project = taskDTO.getProject();
        if (task == null) {
            task = new Task();
            task.setCreatedAt(Timestamp.valueOf(LocalDateTime.now()));
        }
        task.setTaskName(taskDTO.getTaskName());
        task.setDescription(taskDTO.getDescription());
        task.setPriority(taskDTO.getPriority());
        task.setStatus(Status.ACTIVE);
        task.setTaskStatus(taskDTO.getTaskStatus());
        task.setDueDate(taskDTO.getDueDate());
        task.setUpdatedAt(Timestamp.valueOf(LocalDateTime.now()));
        task.setProject(project);
        taskRepository.save(task);

    }

    @Override
    public TaskDTO getTask(Long taskId) {
        Task task = taskRepository.findByIdAndStatus(taskId, Status.ACTIVE).orElse(null);
        if (task == null) {
            return null;
        }
        return taskMapper.toDto(task);
    }

    @Override
    public void deleteTask(Long taskId) {
        Task task = taskRepository.findByIdAndStatus(taskId, Status.ACTIVE).orElse(null);
        if (task == null) {
            throw new RuntimeException("No task found with id " + taskId);
        }
        task.setStatus(Status.DELETED);
        taskRepository.save(task);

    }

    @Override
    public List<TaskDTO> getTasks(List<Long> projectIds, String search, String sortBy, String page, String size) {
        int pageNumber = Integer.parseInt(page);
        int pageSize = Integer.parseInt(size);

        Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by(sortBy).ascending());

        Page<Task> taskPage;

        if (search != null && !search.isEmpty()) {
            taskPage = taskRepository.findByProjectIdInAndStatusAndTaskNameContainingIgnoreCase(projectIds, Status.ACTIVE, search, pageable);
        } else {
            taskPage = taskRepository.findByProjectIdInAndStatus(projectIds, Status.ACTIVE, pageable);
        }

        List<Task> tasks = taskPage.getContent();
        return tasks.stream().map(taskMapper::toDto).toList();
    }



}
