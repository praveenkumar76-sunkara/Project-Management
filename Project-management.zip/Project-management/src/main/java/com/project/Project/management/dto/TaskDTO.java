package com.project.Project.management.dto;

import com.project.Project.management.domain.Project;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.project.Project.management.utils.Priority;
import com.project.Project.management.utils.TaskStatus;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskDTO {

    private Long id;

    private String taskName;

    private String description;

    private Priority priority;

    private TaskStatus taskStatus;

    private Date dueDate;

    private Date createdAt;

    private Date updatedAt;

    private Project project;
}
