package com.project.Project.management.dto;

import com.project.Project.management.utils.Status;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectDTO {


    private Long id;

    @NonNull
    private String name;

    @NonNull
    private String description;

    private Date createdAt;

    private Date updatedAt;

    private Status status;
}
