package com.project.Project.management.utils;

public enum TaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}
