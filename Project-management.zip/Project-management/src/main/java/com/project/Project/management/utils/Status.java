package com.project.Project.management.utils;

public enum Status {
    ACTIVE,
    INACTIVE,
    DELETED
}
