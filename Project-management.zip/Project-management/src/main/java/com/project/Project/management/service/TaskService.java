package com.project.Project.management.service;

import com.project.Project.management.dto.TaskDTO;

import java.util.List;

public interface TaskService {
    void createTask(TaskDTO taskDTO);

    TaskDTO getTask(Long taskId);

    void deleteTask(Long taskId);

    List<TaskDTO> getTasks(List<Long> projectIds, String search, String sortBy, String page, String size);
}
