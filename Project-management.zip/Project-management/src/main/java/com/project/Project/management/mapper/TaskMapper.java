package com.project.Project.management.mapper;

import com.project.Project.management.domain.Task;
import com.project.Project.management.dto.TaskDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface TaskMapper {
    TaskDTO toDto(Task task);
}
